import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from './pages/Login'
import Home from './pages/Home'
import Register from './pages/Register'
import Single from './pages/Single'
import NavBar from './components/NavBar';
import Footer from './components/Footer';
import Write from './pages/Write'

function App() {
  
  return (
    <div className="App">
     
    
          <BrowserRouter>
            <NavBar/>
      <Routes>
       
          <Route index element={<Home />} ></Route>
          <Route path="/Login" element={<Login />} ></Route>
          <Route path="/Register" element={<Register />} ></Route>
          <Route path="/post/:id" element={<Single />} ></Route>
          <Route path="/write" element={<Write />} ></Route>
          {/* <Route path="*" element={<NoPage />} /> */}
        
      </Routes>
       <Footer/>
    </BrowserRouter>
   
    </div>
  );
}

export default App;
