/* eslint-disable react-hooks/rules-of-hooks */
import axios from 'axios';
import { createContext, useEffect, useState } from 'react';
export const AuthContext = createContext();
export const AuthContextProvider=({children})=>{
    const [currentUser,SetCurrentUser]=useState(JSON.parse(localStorage.getItem('user'))||null)
    const login=async(input)=>{
        const res=await axios.post('/auth/login/',input);
        SetCurrentUser(res.data)
    }
    const logout=async(input)=>{
        const res=await axios.post('/auth/logout/');
        SetCurrentUser(null)
    }
    useEffect(() => {
      localStorage.setItem('user',JSON.stringify(currentUser))
    }
      , [currentUser]);
      return(
        <AuthContext.Provider value={{login,logout,currentUser}}>
            {children}
        </AuthContext.Provider>
      )
    
    
}