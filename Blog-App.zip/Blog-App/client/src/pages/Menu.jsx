import React, { useEffect ,useState } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom';
const Menu = ({cat}) => {
    const [post, setPost] = useState([]);

   
    useEffect(() => {
      const fetchData = async () => {
        try {
          const res = await axios.get('/posts/?cat=' + cat);
          setPost(res.data)
        } catch (error) {
          console.log(error)
        }
      }
      fetchData();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [cat])
    
    return (
        <div className="menu">
           <h2> More Results</h2>
            <div className="posts">
                {post.map((p) => (
                    <div className="post" key={p.idpost}>
                        <img src={'/uplaods/'+p.img} alt={p.title} />
                        <h3>{p.title}</h3>
                        <button><Link  to={'/post/'+p.idpost} style={{textDecoration:'none',fontSize:'14px'}}>Learn more</Link></button>
                    </div>
                ))}

            </div>
        </div>
    )
}

export default Menu