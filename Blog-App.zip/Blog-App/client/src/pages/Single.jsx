import React, { useState, useContext } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import Menu from './Menu'
import avatar from '../img/avatart.png'
import { useEffect } from 'react'
import axios from 'axios'
import moment from 'moment'
import { AuthContext } from '../context/authContext'
const Single = () => {
  const { currentUser } = useContext(AuthContext)
  const [post, setPost] = useState([]);
  const [likes, setLikes] = useState([]);
  const location = useLocation();
  const id = location.pathname.split('/')[2];
  const navigate = useNavigate();
  console.log(id);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get('/posts/' + id);
        // const likes_res = await axios.get('/posts/likes/' + id);
        setPost(res.data)
        // setLikes(likes_res);
      } catch (error) {
        console.log(error)
      }
    }
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])
  const fetchData = async () => {
    try {
      const likes_res = await axios.get('/posts/likes/' + id);
      setLikes(likes_res.data);
    } catch (error) {
      console.log(error)
    }
  }
  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, post])
  // handelDelete 
  const handlRemove = async () => {
    try {
      await axios.delete('/posts/' + id);
      navigate('/')
    } catch (error) {
      console.log(error)
    }
  }
  // romve html tag 
  const getText = (html) => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return doc.body.textContent;
  }
  const handelLike = async () => {
    try {
      const data = await axios.post('/posts/likes/' + id);
      fetchData();
    } catch (error) {
      console.log(error)
    }
  }
  return (
    <div className="single">
      {post.map((p) => (
        <div className="container">
          <div className="content">
            <img src={'/uplaods/' + p.img} alt="" srcset="" />
            <div className="user">
              <img src={avatar} alt="" />
              <div className="user-info">
                <p>{p.username}</p>
                <p>Posted {moment(p.date).fromNow()} </p>
              </div>
              {
                currentUser?.username === p.username &&
                <div className="post-mange">
                  <button><Link to={`/write?edit/${p.idpost}`} state={p}><i class="fa-solid fa-pen-to-square"></i></Link></button>
                  <button onClick={handlRemove} style={{ cursor: 'pointer' }}><i class="fa-solid fa-trash"></i></button>
                </div>
              }
            </div>
            <h3>{p.title}</h3>
            <p>{getText(p.text)}</p>
       
<div className="likes">
<button onClick={handelLike}><i class="fa-solid fa-heart"></i></button><b id='like'>{(likes> 1 ? likes+ " likes" : likes + " like")}</b>
</div>        

          </div>
          <div className="menu">
            <Menu cat={p.cat} />
          </div>
        </div>
      ))}
    </div >
  )
}
export default Single