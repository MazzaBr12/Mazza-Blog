import React, { useState } from 'react'
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import moment from 'moment'
import axios from "axios";
import { Link, useLocation, useNavigate } from 'react-router-dom';

const Write = () => {
  const state=useLocation().state;
  const navigate = useNavigate();
  const [err,setErr]=useState(null);
  const [value, setValue] = useState(state?.text || "");
  const [title, setTitle] = useState(state?.title||"");
  const [file, setFile] = useState(null);
  const [cat, setCat] = useState("");
  const [res,setRes]=useState('')
  const upload = async (e) => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res=await axios.post('/upload', formData);
      return res.data;
    } catch (error) {
      
    }
  }
  const handelSubmit = async(e) => {
    e.preventDefault();
    const imgUrl= await upload();
    try {
      const data= await state?.idpost?
       axios.put('/posts/'+state?.idpost,{
        title,text:value,img:file?imgUrl:state?.img,cat
      }):axios.post('/posts',{
        title,
        text:value,
        img:file?imgUrl:'',
        cat,
        date:moment(Date.now()).format('YYYY-MM-DD hh:mm:ss')

      });
       setRes((await data).data);
      // navigate('/');
    } catch (error) {
      setErr(error.response.data);
    }
  }
  console.log(err)
  return (
    <div className="add">
                {res && <b style={{color:'green',fontSize:"18px"}} className='res'>{res +" "}<Link to="/">Back Home</Link></b>}
      <div className="container">
        <div className="content">

          <input type="text" value={title} placeholder='Title .....' onChange={e => setTitle(e.target.value)} />
          <div className="editorContainer">
            <ReactQuill theme="snow" value={value} onChange={setValue} />
          </div>
        </div>
        <div className="menu">
        <div className="item">
            <h1>Category</h1>
            <input type="radio" checked = {state?.cat ==='art'?true :false} name="cat" value='art' onChange={e => setCat(e.target.value)} />
            <label htmlFor="art">Art</label>
            <input type="radio" checked= {state?.cat==='science' ?true:false} name="cat" value='science' onChange={e => setCat(e.target.value)} />
            <label htmlFor="science">Science</label>
            <input type="radio" checked= {state?.cat ==='technology'?true:false} name="cat" value='technology' onChange={e => setCat(e.target.value)} />
            <label htmlFor="technology">Technology</label>
            <input type="radio" checked= {state?.cat ==='cinema' ?true:false} name="cat" value='cinema' onChange={e => setCat(e.target.value)} />
            <label htmlFor="cinema">Cinema</label>
            <input type="radio" checked= {state?.cat ==='design'?true:false} name="cat" value='design' onChange={e => setCat(e.target.value)} />
            <label htmlFor="design">Design</label>
            <input type="radio" checked= {state?.cat ==='food' ?true:false} name="cat" value='food' onChange={e => setCat(e.target.value)} />
            <label htmlFor="food">Food</label>
          </div>
          <div className="item">
            <h1>Publish</h1>
            <span>
              <b>Stutus </b>draft
            </span>
            <span>
              <b>Visibility </b>public
            </span>
            <input type="file"  id="file" style={{ display: 'none' }} onChange={e => setFile(e.target.files[0]) } />
            <label htmlFor="file"><i class="fa-regular fa-file-image"></i></label>
            <div className="buttons">
              <button>Save as a draf </button>
              <button onClick={handelSubmit}>{state?'Update':'Publish'}</button>
            </div>
          </div>


        </div>
      </div>

    </div>
  )
}

export default Write