import React, { useState } from 'react'
import './styles.scss'
import axios from 'axios'
import { Link ,useNavigate} from 'react-router-dom'
const Register = () => {
  const [input, setInput] = useState({
    email: '',
    username: '',
    password: ''
  });
  const [err,setError]=useState(null);
  console.log(input)
  const handelChange=e=>{
    setInput((prev)=>({...prev,[e.target.name]:e.target.value}))
  }
  const navigate=useNavigate();
  const handeSubmit=async(e)=>{
   e.preventDefault();
   try {
    await axios.post('/auth/register/',input);
    navigate('/login')
   } catch (error) {
    setError(error.response.data);
   }
  }
  return (

    <div className='auth'>

      <h1>Register</h1>
      <form>
        <input required type="text" placeholder='username' name='username' onChange={handelChange}/>
        <input required type="email" placeholder='email' name='email' onChange={handelChange}/>
        <input required type="password" placeholder='Password' name='password' onChange={handelChange}/>
        <button onClick={handeSubmit}>Save</button>
        {err && <p>{err}</p>}
        <span>If you have an account <Link to={'/Login'}>Log in</Link></span>
      </form>
    </div>


  )
}

export default Register