import React ,{useContext, useState} from 'react'
import './styles.scss'
import { Link ,useNavigate} from 'react-router-dom'
import axios from 'axios'
import { AuthContext } from '../context/authContext'
const Login = () => {
  const [input, setInput] = useState({
    username: '',
    password: ''
  });
  const {login}=useContext(AuthContext)
  const [err,setError]=useState(null);
  console.log(input)
  const handelChange=e=>{
    setInput((prev)=>({...prev,[e.target.name]:e.target.value}))
  }
  const navigate=useNavigate();
  const handeSubmit=async(e)=>{
   e.preventDefault();
   try {
    await login(input);
    // await axios.post('/auth/login/',input);
    navigate('/')
   } catch (error) {
    setError(error.response.data);
   }
  }
  return (
  
    <div className='auth'>
      
        <h1>LOG IN</h1>
        <form>
          <input required type="text" placeholder='username ...' name='username' onChange={handelChange}/>
          <input required type="password" placeholder='Password ...' name='password' onChange={handelChange}/>
          <button onClick={handeSubmit}>LOG IN</button>
          {err && <p>{err}</p>}
          <span>If you don't have an account <Link to={'/Register'}>Register</Link></span>
        </form>
      </div>   
  )
}

export default Login