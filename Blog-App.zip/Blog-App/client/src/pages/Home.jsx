import React, { useEffect, useState } from 'react'
import axios from 'axios'
import {Link, useLocation} from 'react-router-dom'
const Home = () => {
  const [posts,setPosts]=useState([]);
  const cat=useLocation().search
  useEffect(()=>{
    const fetchData=async()=>{
      try {
        const res=await axios.get('/posts'+cat);
        setPosts(res.data)
        console.log(posts)
      } catch (error) {
        console.log(error)
      }
    }
    fetchData();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[cat])

  function removeHtmlTags(text) {
    const clean = text.replace(/<\/?[^>]+(>|$)/g, "");
    return clean;
  }
  return (
    <div className="home"> 
    <div className="container">
      <div className="posts">
         {posts.length>0?  posts.map((post) => (
         
          <div className='post' key={post.idpost}>
            <div className="post-img">
              <img src={'/uplaods/'+post.img} alt="" srcset="" />
            </div>
            <div className='post-content'>
              <h3>{post.title}</h3>
              <p>{removeHtmlTags((post.text).slice(0,300)+' ...')}</p>
              <button ><Link  to={'/post/'+post.idpost} style={{textDecoration:'none'}}>Learn more</Link></button>
              
            </div>
          </div>
          )):<h2 style={{color:"#CD3DF1",marginTop:'100px'}}> No More Posts <i class="fa-solid fa-face-sad-tear"></i>...</h2>}
        
        </div>

      </div>
    </div>
  )
}

export default Home