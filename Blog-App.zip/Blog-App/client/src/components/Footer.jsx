import React from 'react'
import Logo from '../img/logo.png'

const Footer = () => {
  return (
    <div className="footer">
      <div className="container">
        <img src={Logo} alt="" srcset="" />
         <p>All right was reserved Copyright@2023</p>
      </div>
    </div>
  )
}

export default Footer