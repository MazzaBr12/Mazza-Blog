import React, { useContext } from 'react'
import Logo from '../img//logo.png'
import { Link, useNavigate } from 'react-router-dom'
import { AuthContext } from '../context/authContext'

const NavBar = () => {
  const navigate = useNavigate();
  const { currentUser, logout } = useContext(AuthContext)
  const handelClick = async () => {
    await logout();
    navigate('/login');

  }
  const logoutStl = {
    color: 'red',
    cursor: 'pointer'
  }
  return (
    <div className="container">
      <div className="navbar">
        <div className="logo">
          <Link to='/'><img src={Logo} alt="" srcset="" /></Link>
        </div>
        <div className="links">
          <div className="cat">
            <Link className='link ' to='/?cat=art'><h6>Art</h6></Link>
            <Link className='link ' to='/?cat=science'><h6>Science</h6></Link>
            <Link className='link ' to='/?cat=technology'><h6>Technologie</h6></Link>
            <Link className='link ' to='/?cat=cinema'><h6>Cinema</h6></Link>
            <Link className='link ' to='/?cat=design'><h6>Design</h6></Link>
            <Link className='link ' to='/?cat=food'><h6>FOOD</h6></Link>
          </div>

          {

            currentUser ? <span>{currentUser.username}</span> : ''

          }
          {currentUser ?
            <span onClick={handelClick} style={logoutStl}>LOG out </span>
            :
            (
              <div className="login">
                <Link  to='/login' className='link'>Log In</Link>
              </div>
            ) }
          <div className='to-write'>
            <Link to={'/write'} className='link'>Write ...</Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default NavBar