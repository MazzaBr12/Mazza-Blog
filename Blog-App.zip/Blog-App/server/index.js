import express from 'express'
const app = express();
import cors from 'cors'
import cookieParser from 'cookie-parser';
import postRouter from './routes/post.js'
import authRouter from './routes/auth.js'
import userRouter from './routes/user.js'
import multer from 'multer'

app.use(express.json());
app.use(cookieParser());
app.use('/api/posts/', postRouter);
app.use('/api/auth/', authRouter);
app.use('/api/users/', userRouter);
app.listen(5000, (err) => {
    if (err) {
        return err;
    }
    console.log('server is running on port ' + 5000);
});
//  uloading img
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, '../client/public/uplaods')
    },
    filename: function (req, file, cb) {


        cb(null, Date.now() + "-" + file.originalname)

    }
})
const upload = multer({ storage })

app.post('/api/upload', upload.single('file'), function (req, res) {
    const file = req.file;
    res.status(200).json(file.filename);
    
})
