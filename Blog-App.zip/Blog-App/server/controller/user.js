export const addUser=(req,res)=>{
    res.send('Goof idea !');
}
export const getAllUsers=(req,res)=>{
    res.send('Goof idea !');
}
export const getUser=(req,res)=>{
    res.send('Goof idea !');
}
export const deleteUser=(req,res)=>{
    res.send('Goof idea !');
}
