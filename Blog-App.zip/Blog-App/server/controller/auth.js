import bcrypt from 'bcrypt'
import db from '../db.js'
import jwt from 'jsonwebtoken'
export const register = (req, res) => {
    const q = 'select * from users where email=? or username =?';
    db.query(q, [req.body.email, req.body.username], (err, data) => {
        if (err) return res.json(err);
        if (data.length) return res.status(409).json('user is already exist ');
        // hashing password 
        const salt = bcrypt.genSaltSync(10);
        const hash = bcrypt.hashSync(req.body.password, salt);
        const q="INSERT INTO USERS (`username`,`email`,`password`) values(?)";
        const value=[req.body.username,req.body.email,hash];
        db.query(q,[value],(err,data)=>{
            if(err) return  res.json(err);
            res.status(200).json('User has been created !')
        })
    }) 
}
export const login = (req, res) => {
    const q="select * from users where username=?";
    
    db.query(q,req.body.username,(err,data)=>{
        if(err) return res.json(err);
        if(data.length==0) return res.status(404).json('User or password is wrong');
        // check Password
        const comparePass=bcrypt.compareSync(req.body.password, data[0].password); 
         if(!comparePass) return res.status(404).json('User or password is wrong');
         const token =jwt.sign({id:data[0].id},'mazzakey');
         const {password,...others}=data[0];
         res.cookie('access_token',token,{httpOnly:true}).status(200).json(others)

    })
}
export const logout = (req, res) => {
   res.clearCookie('access-token',{
    sameSite:'none',
    secure:true
   }).status(200).json('Useg has been logged out !');
}