import db from '../db.js';
import jwt from 'jsonwebtoken'
export const addPost = (req, res) => {
    const token = req.cookies.access_token;
    if (!token) return res.json('Not Athenticated ');
    jwt.verify(token, 'mazzakey', (err, userInfo) => {
        if (err) return res.status(404).json('Token is not valid !');
        const q = 'INSERT INTO posts(`title`,`text`,`img`,`date`,`cat`,`userid`) VALUES(?)';
        const values = [
            req.body.title,
            req.body.text,
            req.body.img,
            req.body.date,
            req.body.cat,
            userInfo.id
        ]
        db.query(q, [values], (err, data) => {
            if (err) res.json(err);
            res.status(200).json("User has been seved successfully !");
        })
    })

    /*
    title,text:value,img:file?imgUrl:'',cat,date:moment(Date.now()).format('YYYY-MM-DD HH:mm:ss' )*/
}
export const update = (req, res) => {
    const token = req.cookies.access_token;
    if (!token) return res.json('Not Athenticated ');
    jwt.verify(token, 'mazzakey', (err, userInfo) => {
        if (err) return res.status(404).json('Token is not valid !');
        const q = 'update  posts set `title`=?,`text`=?,`cat`=?,`img`=? where `idpost`=? and userid =?';
        const values = [
            req.body.title,
            req.body.text,
            req.body.cat,
            req.body.img,

        ]
        db.query(q, [...values, req.params.idpost, userInfo.id], (err, data) => {
            if (err) res.json(err);
            res.status(200).json("Post has been updated !");
        })
    })
}
export const getAllPosts = (req, res) => {
    const cat = req.query.cat;
    const q = cat ? "SELECT * FROM POSTS WHERE cat= (?) ORDER BY date asc" : "SELECT * FROM POSTS ORDER BY date ";
    db.query(q, [cat], (err, data) => {
        if (err) return res.json(err);
        res.status(200).json(data);
    })
}
// likes 
export const like = (req, res) => {
    let likes=0;
    const token = req.cookies.access_token;
    if (!token) return res.status(404).json('Not Athenticated ');
    jwt.verify(token, 'mazzakey', (err, userInfo) => {
        const checkUser = "select * from likes where iduser=? and idpost=?";
        if (err) return res.status(404).json('Token is not valid !');
        // const value=[ userInfo.id,req.params.idpost]
        db.query(checkUser,[userInfo.id,req.params.idpost], (err, checkUser) => {
            if (err) return res.json(err);
            
            if (checkUser.length === 0) {
                const q = 'insert into likes(`iduser`,`idpost`) values(?) ';
                const values = [ userInfo.id,req.params.idpost]
                db.query(q,[values], (err, data) => {
                    if (err) res.json(err);
                    console.log(checkUser)
                    res.status(200).json("insert");
                })
                return ;
            }if(checkUser.length>0) {
                const q = 'DELETE FROM LIKES WHERE `IDPOST`=? and `IDUSER`=?';
                db.query(q,  [req.params.idpost,userInfo.id], (err, data) => {
                    if (err) res.json(err);
                    res.status(200).json("deleted");
                }) 
            }
        })

    })
}
// getLikes
export const getLikes=async(req,res)=>{
    const rows = "SELECT count(*) as likescount from likes where `idpost`=?" ;
    db.query(rows,req.params.idpost, (err, data) => {
        if (err) return res.json(err);
        res.status(200).json(data[0].likescount);
    })  
    

}
// 
export const getPost = (req, res) => {


    const q = 'SELECT p.idpost, `username`,`title`,`text`,p.img,u.img as userImg,`cat`,`date` from users u join posts p on u.id=p.userid where idpost=(?)';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        res.status(200).json(data);
    })
}
export const deletePost = (req, res) => {
    const token = req.cookies.access_token;
    if (!token) return res.status(404).json('Not Athenticated ');
    jwt.verify(token, 'mazzakey', (err, userInfo) => {
        if (err) return res.status(404).json('Token is not valid !');
        const q = 'DELETE FROM posts where idpost=(?) and userid=(?)';
        db.query(q, [req.params.id, userInfo.id], (err, data) => {
            if (err) res.json(err);
            res.status(200).json(data);
        })
    })

}
