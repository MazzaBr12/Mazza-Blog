import express from 'express'
const router = express.Router();
import {  addUser,deleteUser,getAllUsers,getUser} from '../controller/user.js';
router.post('/',addUser);
router.delete('/',deleteUser);
router.get('/',getUser);
router.get('/',getAllUsers);

export default router