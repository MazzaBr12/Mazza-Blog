import express from 'express'
const router = express.Router();
import { addPost ,deletePost,getPost,getAllPosts,update,like,getLikes} from '../controller/post.js';
router.post('/',addPost);
router.put('/:idpost',update);
router.delete('/:id',deletePost);
router.get('/:id',getPost);
router.get('/',getAllPosts);
// like
router.post('/likes/:idpost',like)
router.get('/likes/:idpost',getLikes)
export default router